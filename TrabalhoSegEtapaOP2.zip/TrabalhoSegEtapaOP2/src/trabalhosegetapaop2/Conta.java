/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhosegetapaop2;

/**
 *
 * @author Guto
 */
public class Conta {
    private int numero;
    private float saldo;
    private String nome;
    private String senha;

    public Conta(int numero, float saldo, String nome, String senha) {
        this.numero = numero;
        this.saldo = saldo;
        this.nome = nome;
        this.senha = senha;
    }

    public Conta() {
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
