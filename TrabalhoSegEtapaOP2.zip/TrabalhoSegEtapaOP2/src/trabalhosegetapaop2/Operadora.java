/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhosegetapaop2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdk.nashorn.internal.objects.NativeArray;

/**
 *
 * @author 20172PF.CC0052
 */
public class Operadora extends Thread {

    private static Vector clientes; // Cria um vetor de todas as conexoes 
    private Socket conexao; // Socket do cliente
    private String meuNome; // Nome de cliente
     float saldo;
    static ArrayList<Conta> contas = new ArrayList();
 

    public Operadora(Socket socket) {
        this.conexao = socket;
    }

    public static void main(String[] args) {
        clientes = new Vector();
        try {
            ServerSocket servidor = new ServerSocket(2222);
   
            contas.add(new Conta(500, 0, "Clover","123"));
            contas.add(new Conta(501, 0, "Sam","321"));
            contas.add(new Conta(502, 0, "Alex","231"));
            
            
            
            while (true) {
                // O servidor fica bloqueado ate algum cliente conectar, 
                // quando houver a conexao, o servidor desbloqueia a porta
                // principal e cria uma nova conexao secundaria para o cliente
                System.out.println("Esperando alguem se conectar...");
                Socket conexao = servidor.accept();
                System.out.println("Alguem conectou...");
                Thread t = new Operadora(conexao);
                t.start();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void run() {
        boolean flag = false;
        try {
            BufferedReader entrada = new BufferedReader(new InputStreamReader(conexao.getInputStream()));

            PrintStream saida = new PrintStream(conexao.getOutputStream());
            this.meuNome = entrada.readLine();

            if (this.meuNome == null) {
                return;
            }
            clientes.add(saida);

            String linha = entrada.readLine();
           
            
            
while (linha!=null && !(linha.trim().equals("")))
    
{   PrintStream cha = (PrintStream) clientes.lastElement();                     
    saida.println("1 - Adicionar creditos ; 2 - Consultar credito: ");
                       linha = entrada.readLine();
                        if(!linha.equals("1") && !linha.equals("2"))
                           cha.println("opção invalida! Tente novamente");
                       if(linha.equals("1"))
                       {
                           
                        
                        cha.println(meuNome + " Insira a conta que deseja adicionar creditos: ");
                           linha=entrada.readLine();
                           
                           for(Conta c:contas)
                           {
                               if(c.getNumero()==Integer.parseInt(linha))
                               {
                         cha = (PrintStream) clientes.lastElement();
                        cha.println(meuNome +" Conta localizada em nome de "+c.getNome());
                        cha.println("\n Insira a quantidade de creditos que deseja inserir: ");
                        linha=entrada.readLine();
                       
                        saldo=saldo + Float.parseFloat(linha);
                        c.setSaldo(saldo);
                        cha.println(meuNome +"\n Saldos atualizados na conta de "+c.getNome()+"!");
                        flag = true;
                               }
                               
                           }
                           if(!flag)
                               {
                                   cha.println("A conta informada não existe! Tente novamente");
                               }
                       }
                       
                       if(linha.equals("2"))
                       {
                            //PrintStream cha = (PrintStream) clientes.lastElement();
                        cha.println(meuNome + " Insira a conta que deseja consultar os creditos: ");
                           linha=entrada.readLine();
                           
                           for(Conta c:contas)
                           {
                               if(c.getNumero()==Integer.parseInt(linha))
                               {
                         cha = (PrintStream) clientes.lastElement();
                        cha.println(meuNome +" Conta localizada em nome de "+c.getNome());
                        cha.println(meuNome +" Insira a senha para realizar a consulta "+c.getNome());
                        linha=entrada.readLine();
                            if(linha.equals(c.getSenha()))
                            {
                                 cha.println(meuNome +" O saldo da conta de  "+c.getNome()+ " é de "+c.getSaldo());
                            }
                            else
                            {
                                cha.println("Senha invalida!");
                            }
                               }
                                else
                               {
                                  
                               }
                       }
                           
    
//for (int i = 0; i < 3; i++) {
//                if (contas[i].getNumero() == Integer.parseInt(array[0].trim())) {
//                    if (Integer.parseInt(array[1].trim()) == 1) {
//                        //this.sendToAll(saida, " Conta em nome de " + contas[i].getNome() + " localizada com saldo de ", contas[i].getSaldo() + "");
//                        PrintStream cha = (PrintStream) clientes.lastElement();
//                        cha.println(meuNome +" Conta localizada em nome de "+contas[i].getNome()+" com saldo de " + contas[i].getSaldo());
////                        saida.println("nova operação: ");
////                       linha = entrada.readLine();
//                        
//                        
//                    } else if (Integer.parseInt(array[1].trim()) == 2) {
//                      
//                        float saldo = contas[i].getSaldo();
//                        saldo = saldo - Integer.parseInt(array[2].trim());
//                        contas[i].setSaldo(saldo);
//                        
//                        PrintStream cha = (PrintStream) clientes.lastElement();
//                        cha.println(meuNome +" Saque da conta de "+contas[i].getNome()+" com saldo de " + contas[i].getSaldo());
////                            saida.println("nova operação: ");
////                       linha = entrada.readLine();
//                      //  this.sendToAll(saida, " Saque efetuado", "");
//                    } else if (Integer.parseInt(array[1].trim()) == 3) {
//                        float saldo = contas[i].getSaldo();
//                        saldo = saldo + Integer.parseInt(array[2].trim());
//                        contas[i].setSaldo(saldo);
//
//                         PrintStream cha = (PrintStream) clientes.lastElement();
//                        cha.println(meuNome +" Deposito da conta de "+contas[i].getNome()+" com saldo de " + contas[i].getSaldo());
//                        //this.sendToAll(saida, " Deposito efetuado", "");
////                        saida.println("nova operação: ");
////                       linha = entrada.readLine();
//                        
//                    }
//
//                }
//
//
//           
//            }
}
                      
            
        } 

    }   catch (IOException ex) {
            Logger.getLogger(Operadora.class.getName()).log(Level.SEVERE, null, ex);
        }

//    public void sendToAll(PrintStream saida, String acao, String linha) {
//        try {
//            Enumeration e = clientes.elements();
//            while (e.hasMoreElements()) {
//                
//                PrintStream chat = (PrintStream) e.nextElement();
//                chat.println(meuNome + acao + linha);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }

}
}
